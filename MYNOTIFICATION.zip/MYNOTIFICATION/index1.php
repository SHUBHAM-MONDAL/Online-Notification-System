<?php
      //include("../config/db.php");



    /*$username = "";

  $userid = 0;
  $email = "";
  $location = "";
  $phone = "";
  $fullname = "";
   if(isset($_COOKIE["username"]))
   {
    $username=$_COOKIE["username"];
  }
  else{
    // echo "user not logged in";
    header("location: authentication/login.php");
  }

  $sql = "SELECT * FROM accounts WHERE username = '$username'";

  $query = mysqli_query($conn, $sql);

  if($query){

    $row = mysqli_fetch_assoc($query);

    $userid = $row["userid"];
    $username = $row["username"];
    $password = $row["email"];
    $fullname = $row["fullname"];
    $phone = $row["phone"];
    $location = $row["location"];

  }
  else{
    echo "Error making the query";
  }*/


      ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Online Notification System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
  <style>
  .fakeimg {
    height: 200px;
    background: #aaa;
  }
  </style>
<script>
 
$(document).ready(function(){
 
// updating the view with notifications using ajax
 
function load_unseen_notification(view = '')
 
{
 
 $.ajax({
 
  url:"fetch.php",
  method:"POST",
  data:{view:view},
  dataType:"json",
  success:function(data)
 
  {
 
   $('.dropdown-menu').html(data.notification);
 
   if(data.unseen_notification > 0)
   {
    $('.count').html(data.unseen_notification);
   }
 
  }
 
 });
 
}
 
load_unseen_notification();
 
// submit form and get new records
 
$('#comment_form').on('post', function(event){
 event.preventDefault();
 
 if($('#subject').val() != '' && $('#comment').val() != '')
 
 {
 
  var form_data = $(this).serialize();
 
  $.ajax({
 
   url:"insert.php",
   method:"POST",
   data:form_data,
   success:function(data)
 
   {
 
    $('#comment_form')[0].reset();
    load_unseen_notification();
 
   }
 
  });
 
 }
 
 else
 
 {
  alert("Both Fields are Required");
 }
 
});
 
// load new notifications
 
$(document).on('click', '.dropdown-toggle', function(){
 
 $('.count').html('');
 
 load_unseen_notification('yes');
 
});
 
setInterval(function(){
 
 load_unseen_notification();;
 
}, 5000);
 
});
 
</script>


</head>
<body>

<div class="jumbotron text-center" style="margin-bottom:0">
  <img background="images.jpg">
  <h1>Online Notification System</h1>
</div>

<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <a class="navbar-brand" href="#">SIET SHUATS</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="#">ADMIN</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">ME</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#"></a>
      </li>    
    </ul>
  </div> 
 
  <ul class="nav navbar-nav navbar-right">
 
     <li class="dropdown">
 
      <a href="index2.php" class="dropdown-toggle" data-toggle="dropdown"><span class="label label-pill label-danger count" style="border-radius:20px;"></span> <span class="glyphicon glyphicon-bell" style="font-size:18px;"></span></a>
 
      <ul class="dropdown-menu"></ul>
 
     </li>

</nav>


    <div class="card" style="width:30%">
    <img class="card-img-top" src="img/img_avatar1.png" alt="Card image" style="width:100%">
    <div class="card-body">
      <h4 class="card-title">
        
      </h4>
      <p class="card-text">Dean</p></div></div>



      <div class="form-group" method="post" id="comment_form">
  <label for="usr">Subject:</label>
  <input type="text" class="form-control" id="usr">
</div>
<div class="form-group">
  <label for="comment">Comment:</label>
  <textarea class="form-control" rows="10" id="comment"></textarea>
  <center>
    <input type="submit" name="post" id="post" class="btn btn-info" value="Post" /></center>

   <button type="button" class="btn btn-primary active" position="right">Logout</button>
</div>





</body>
</html>
