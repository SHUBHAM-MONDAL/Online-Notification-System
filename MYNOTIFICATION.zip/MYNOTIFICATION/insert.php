<?php
 
if(isset($_POST["subject"]))
 
{
 
include("config/db.php");
 
$subject=$_POST["subject"];
 
$comment=$_POST["comment"];
 
$query = "INSERT INTO comments(comment_subject, comment_text)VALUES ('$subject', '$comment')";
 
mysqli_query($conn, $query);
 
}
if($query)
{
	header("location:index.php");
}
else
{
	echo("Message couldn't be sent");
}

 
?>