<?php
  
  if(isset($_COOKIE["username"])){
    header("location: ../dashboard");
  }

?>
<!DOCTYPE html>
<html>
  <head>
    <title>Register - Twitter</title>
    <link rel="stylesheet" href="../css/login.css" />
    <!--- Include CSS from css/login.css --->
    <!--- Include Boostrap CSS --->
    <link rel="stylesheet" href="../libraries/bootstrap/css/bootstrap.min.css" />
    <!--- Include jQuery --->
    <script src="../libraries/jquery/jquery-3.3.1.min.js"></script>
    <!--- Include Bootstrap JS --->
    <script src="../libraries/bootstrap/js/bootstrap.min.js"></script>
  </head>
  <body>
    <div class="container">
      <div class="row">
        <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
          <div class="card card-signin my-5">
            <div class="card-body">
              <h5 class="card-title text-center">Sign In</h5>
              <form class="form-signin" action="register.do.php" method="post" >
                <div class="form-label-group">
                   <label for="inputEmail">Email address</label>
                  <input type="email" id="inputEmail" name="inputEmail" class="form-control" placeholder="Email address" required autofocus>
                </div>

                <div class="form-label-group">
                    <label for="inputUsername">Username</label>
                  <input type="text" id="inputUsername" name="inputUsername" class="form-control" placeholder="username" required>
                </div>

                <div class="form-label-group">
                    <label for="inputPassword">Password</label>
                  <input type="password" id="inputPassword" name="inputPassword" class="form-control" placeholder="Password" required>
                
                </div>

                <div class="form-label-group">
                     <label for="inputFullname">Full Name</label>
                  <input type="text" id="inputFullname" name="inputFullname" class="form-control" placeholder="Full Name" required>
               
                </div>

                <div class="form-label-group">
                  <label for="inputPhone">Phone Number</label>

                  <input type="text" id="inputPhone" name="inputPhone" class="form-control" placeholder="9123xxxxxx" required>
                                  </div>

                <div class="form-label-group">
                <label for="inputLocation">Location</label>
                  <input type="text" id="inputLocation" name="inputLocation" class="form-control" placeholder="City, Country" required autofocus>
                
                </div>


               

                </div>

                <hr/>

                <button class="btn btn-lg btn-primary btn-block text-uppercase" type="submit">Register</button>
                
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>