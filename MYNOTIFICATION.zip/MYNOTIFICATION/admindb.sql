-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 23, 2019 at 06:13 PM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `admindb`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE IF NOT EXISTS `accounts` (
  `userid` int(20) NOT NULL,
  `username` varchar(250) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(25) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `phone` int(11) NOT NULL,
  `location` varchar(55) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`userid`, `username`, `email`, `password`, `fullname`, `phone`, `location`) VALUES
(1, 'Shubham mondal', 'Shubhammandal89@gmail.com', 'e10adc3949ba59abbe56e057f', 'Shubham mondal', 123456789, 'india'),
(2, 'aman chaurasia', 'amanchaurasia57@gmail.com', 'e10adc3949ba59abbe56e057f', 'aman chaurasia', 123456, 'INDIA'),
(3, 'admin', '123@gmail.com', '202cb962ac59075b964b07152', 'admin', 123456, 'india'),
(4, 'adarshpatel', 'adarshpatel2013@gmail.com', 'e10adc3949ba59abbe56e057f', 'adarshpatel', 123456, 'Allahabad');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `comment_id` int(1) NOT NULL,
  `comment_subject` text NOT NULL,
  `comment_text` text NOT NULL,
  `comment_status` int(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`comment_id`, `comment_subject`, `comment_text`, `comment_status`) VALUES
(1, 'shubham mondal', '123456789', 1),
(2, 'shubham mondal', '123456789', 1),
(3, 'shubham mondal', '123456789', 1),
(4, 'shubham mondal', '123456', 1),
(5, 'shubham mondal', '1234565', 1),
(6, 'shubham mondal', 'leave the class right now', 1),
(7, 'shubham mondal', 'shubham123', 1),
(8, 'shubham mondal', '123456789', 1),
(9, 'shubham mondal', 'adasdasdads', 1),
(10, 'shubham mondal', '1234567899', 1),
(11, 'shubham mondal', '1234567899', 1),
(12, 'shubham mondal', '123456', 1),
(13, 'Notice for Leave Management', '123456', 1),
(14, 'shubham mondal', 'asdfghtyui', 1),
(15, 'leave for today ', 'Just Leave the Shepherd Waiting hall And come into dean office', 1),
(16, 'Notice for Leave Management', 'askldhasgdkhsajklashfhhsaihfksjfkhsabcklbshcbkasjbckjdsn', 1),
(17, 'shubham mondal`', 'HGUYFIYIOGTYFGIGFYTGKGYH', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`comment_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `userid` int(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `comment_id` int(1) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
