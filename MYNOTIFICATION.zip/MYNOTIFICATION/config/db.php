<?php

	$host = "localhost";
	$username = "root";
	$password = "";
	$dbname = "admindb";

	$conn = mysqli_connect($host, $username, $password, $dbname);

?>
